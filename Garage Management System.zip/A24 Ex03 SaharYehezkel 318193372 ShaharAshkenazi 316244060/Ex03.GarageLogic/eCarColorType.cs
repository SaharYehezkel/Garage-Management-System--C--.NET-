﻿namespace Ex03.GarageLogic
{
    public enum eCarColorType
    {
        Blue = 1,
        White = 2,
        Red = 3,
        Yellow = 4,
    }
}