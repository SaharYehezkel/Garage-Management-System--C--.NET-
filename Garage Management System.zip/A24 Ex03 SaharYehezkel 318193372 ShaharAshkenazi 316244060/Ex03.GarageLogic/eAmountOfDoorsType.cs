﻿namespace Ex03.GarageLogic
{
    public enum eAmountOfDoorsType
    {
        TwoDoors = 2,
        ThreeDoors = 3,
        FourDoors = 4,
        FiveDoors = 5
    }
}