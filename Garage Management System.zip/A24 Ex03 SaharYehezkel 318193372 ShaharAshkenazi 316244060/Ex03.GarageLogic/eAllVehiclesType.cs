﻿namespace Ex03.GarageLogic
{
    public enum eAllVehiclesType
    {
        FuelCar = 1,
        ElectricCar = 2,
        FuelMotorcycle = 3,
        ElectricMotorcycle = 4,
        FuelTruck = 5
    }
}