﻿using System;


namespace Ex03.GarageLogic
{
    public enum eVehicleGarageStatus
    {
        UnderRepair = 1,
        Fixed = 2,
        Paid = 3
    }
}