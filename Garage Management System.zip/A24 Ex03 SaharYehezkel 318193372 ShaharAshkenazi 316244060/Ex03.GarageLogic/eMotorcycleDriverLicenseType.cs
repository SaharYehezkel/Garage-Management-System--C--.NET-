﻿namespace Ex03.GarageLogic
{
    public enum eMotorcycleDriverLicenseType
    {
        A1 = 1,
        A2 = 2,
        AB = 3,
        B2 = 4
    }
}