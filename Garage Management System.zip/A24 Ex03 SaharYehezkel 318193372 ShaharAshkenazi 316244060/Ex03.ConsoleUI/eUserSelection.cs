﻿namespace Ex03.ConsoleUI
{
    public enum eUserSelection
    {
        AddNewVehicle = 1,
        ShowAllVehiclesInGarage = 2,
        ChangeVehicleStatus = 3,
        TireInflation = 4,
        RefuelFuelEngine = 5,
        RechargeElectricEngine = 6,
        LoadVehicleInfo = 7,
        Exit = 8,
    }
}