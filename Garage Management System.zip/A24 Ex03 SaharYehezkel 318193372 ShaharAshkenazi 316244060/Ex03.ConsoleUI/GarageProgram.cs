﻿using System;

namespace Ex03.ConsoleUI
{
    public class GarageProgram
    {
        public static void Main()
        {
            GarageConsoleInterface garage = new GarageConsoleInterface();
            garage.MainMenuUserSelection();
        }
    }
}